# Student Course Management – Relational Schema

## 1. Relations

### STUDENT
| Attribute | Key |
|---|---|
| Student_ID | Primary Key |
| Student_Name | |
| Email | |
| Department | |

### COURSE
| Attribute | Key |
|---|---|
| Course_ID | Primary Key |
| Course_Name | |
| Trainer_Name | |
| Duration | |

### ENROLLMENT
| Attribute | Key |
|---|---|
| Enrollment_ID | Primary Key |
| Student_ID | Foreign Key → STUDENT(Student_ID) |
| Course_ID | Foreign Key → COURSE(Course_ID) |
| Enrollment_Date | |

## 2. Relationship

STUDENT and COURSE have a many-to-many relationship.  
ENROLLMENT is the relationship/junction relation that connects them.

- ENROLLMENT.Student_ID references STUDENT.Student_ID
- ENROLLMENT.Course_ID references COURSE.Course_ID

## 3. Sample Tuples

### STUDENT
| Student_ID | Student_Name | Email | Department |
|---|---|---|---|
| S001 | Ravi Kumar | ravi@gmail.com | CSE |
| S002 | Priya Sharma | priya@gmail.com | ECE |
| S003 | Anil Kumar | anil@gmail.com | CSE |
| S004 | Sneha Reddy | sneha@gmail.com | IT |
| S005 | Kiran Rao | kiran@gmail.com | EEE |

### COURSE
| Course_ID | Course_Name | Trainer_Name | Duration |
|---|---|---|---|
| C101 | Java Full Stack | Rajesh | 12 Weeks |
| C102 | Python Programming | Suresh | 10 Weeks |
| C103 | Database Management | Anitha | 8 Weeks |

### ENROLLMENT
| Enrollment_ID | Student_ID | Course_ID | Enrollment_Date |
|---|---|---|---|
| E001 | S001 | C101 | 2026-09-01 |
| E002 | S002 | C102 | 2026-09-02 |
| E003 | S003 | C101 | 2026-09-03 |
| E004 | S004 | C103 | 2026-09-04 |
| E005 | S005 | C102 | 2026-09-05 |

## 4. Basic SQL Schema

```sql
CREATE TABLE STUDENT (
    Student_ID VARCHAR(10) PRIMARY KEY,
    Student_Name VARCHAR(100),
    Email VARCHAR(100),
    Department VARCHAR(50)
);

CREATE TABLE COURSE (
    Course_ID VARCHAR(10) PRIMARY KEY,
    Course_Name VARCHAR(100),
    Trainer_Name VARCHAR(100),
    Duration VARCHAR(30)
);

CREATE TABLE ENROLLMENT (
    Enrollment_ID VARCHAR(10) PRIMARY KEY,
    Student_ID VARCHAR(10),
    Course_ID VARCHAR(10),
    Enrollment_Date DATE,
    FOREIGN KEY (Student_ID) REFERENCES STUDENT(Student_ID),
    FOREIGN KEY (Course_ID) REFERENCES COURSE(Course_ID)
);
```

## 5. Definitions

- **Relation:** A table in a relational database.
- **Attribute:** A column/property of a relation.
- **Tuple:** A row/record in a relation.
- **Relational Schema:** The structure that defines relations, attributes and keys.
- **Primary Key:** An attribute that uniquely identifies each tuple in a relation.

## 6. Project Structure

```text
student-course-schema/
├── README.md
├── schema.sql
├── student_relation.png
├── course_relation.png
└── enrollment_relation.png
```

## 7. GitHub Repository

Create a GitHub repository named:

`student-course-schema`

Then upload all files in this folder.
