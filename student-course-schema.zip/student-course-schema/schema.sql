CREATE TABLE STUDENT (
    Student_ID VARCHAR(10) PRIMARY KEY,
    Student_Name VARCHAR(100),
    Email VARCHAR(100),
    Department VARCHAR(50)
);

CREATE TABLE COURSE (
    Course_ID VARCHAR(10) PRIMARY KEY,
    Course_Name VARCHAR(100),
    Trainer_Name VARCHAR(100),
    Duration VARCHAR(30)
);

CREATE TABLE ENROLLMENT (
    Enrollment_ID VARCHAR(10) PRIMARY KEY,
    Student_ID VARCHAR(10),
    Course_ID VARCHAR(10),
    Enrollment_Date DATE,
    FOREIGN KEY (Student_ID) REFERENCES STUDENT(Student_ID),
    FOREIGN KEY (Course_ID) REFERENCES COURSE(Course_ID)
);
